package com.example.expensemanagermobileapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class AddCashActivity : AppCompatActivity() {
    val nameofwallet by lazy { findViewById<EditText>(R.id.addcashbtn) }
    val amountofwallet by lazy { findViewById<EditText>(R.id.addcashbtn) }
    val spinner by lazy { findViewById<Spinner>(R.id.arrow) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_cash)

        fun View.getNameOfBankCard() {
            val msg = nameofwallet.text.toString()
        }

        fun getAmountOfBankCard(view: View) {
            val msg = amountofwallet.text.toString()
        }

        val currencies = resources.getStringArray(R.array.Currencies)


        if (spinner != null) {
            val adapter = ArrayAdapter(this,
                android.R.layout.simple_spinner_item, currencies)
            spinner.adapter = adapter

            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>,
                                            view: View, position: Int, id: Long) {
                    Toast.makeText(this@AddCashActivity,
                        getString(R.string.currency_title) + " " +
                                "" + currencies[position], Toast.LENGTH_SHORT).show()
                }
                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }
    }
}