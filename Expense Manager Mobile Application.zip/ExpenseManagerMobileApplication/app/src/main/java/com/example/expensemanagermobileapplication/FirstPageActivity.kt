package com.example.expensemanagermobileapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class FirstPageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first_page)
    }
}